package com.sidep.proyect.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sidep.proyect.backend.model.ColaPesaje;

public interface ColaPesajeRepository extends JpaRepository<ColaPesaje, Long>{

}
