package com.sidep.proyect.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SidepBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SidepBackendApplication.class, args);
	}

}
