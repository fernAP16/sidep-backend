package com.sidep.proyect.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SidepBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
